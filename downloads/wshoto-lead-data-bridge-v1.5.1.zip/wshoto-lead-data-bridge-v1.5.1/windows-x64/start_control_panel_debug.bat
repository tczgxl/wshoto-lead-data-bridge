@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "PYTHONUTF8=1"

if exist "%~dp0python.exe" (
    "%~dp0python.exe" control_panel.py
    goto :done
)

where py >nul 2>nul
if not errorlevel 1 (
    py -3 control_panel.py
) else (
    python control_panel.py
)

:done
echo.
echo 控制台已退出，按任意键关闭窗口。
pause >nul
