@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "PYTHONUTF8=1"

if not exist ".env" (
    copy /Y ".env.example" ".env" >nul
    echo.
    echo 首次运行：已生成 .env
    echo 请先填写 WSHOTO_CALLBACK_URL 和 MEIQIA_WEBHOOK_SECRET，
    echo 保存后重新双击 start.bat。
    echo.
    start "" notepad ".env"
    pause
    exit /b 1
)

set "PYTHON_EXE=%~dp0python.exe"
set "PYTHON_ARGS="
if not exist "%PYTHON_EXE%" (
    set "PYTHON_EXE="
    where py >nul 2>nul
    if not errorlevel 1 (
        set "PYTHON_EXE=py"
        set "PYTHON_ARGS=-3"
    )
)
if not defined PYTHON_EXE (
    where python >nul 2>nul
    if not errorlevel 1 set "PYTHON_EXE=python"
)
if not defined PYTHON_EXE (
    echo 未找到 Python，请安装 Python 3.10 或更高版本，
    echo 安装时勾选 Add python.exe to PATH。
    pause
    exit /b 1
)

"%PYTHON_EXE%" %PYTHON_ARGS% -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >nul 2>nul
if errorlevel 1 (
    echo Python 版本过低，需要 3.10 或更高版本。
    "%PYTHON_EXE%" %PYTHON_ARGS% --version
    pause
    exit /b 1
)

echo 正在启动服务...
echo 健康检查：http://127.0.0.1:8080/healthz
"%PYTHON_EXE%" %PYTHON_ARGS% app.py

echo.
echo 服务已退出。
pause
