@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "SCRIPT="

if exist "%~dp0MeiqiaWshotoBridge.exe" (
    set "TARGET=%~dp0MeiqiaWshotoBridge.exe"
    goto :create
)

if exist "%~dp0pythonw.exe" if exist "%~dp0control_panel.py" (
    set "TARGET=%~dp0pythonw.exe"
    set "SCRIPT=%~dp0control_panel.py"
    goto :create
)

if exist "%~dp0dist\MeiqiaWshotoBridge.exe" (
    set "TARGET=%~dp0dist\MeiqiaWshotoBridge.exe"
    goto :create
)

set "TARGET=%~dp0start_control_panel.bat"

:create
set "WORKDIR=%~dp0"
set "ICON=%~dp0assets\app.ico"

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws = New-Object -ComObject WScript.Shell; $desktop = [Environment]::GetFolderPath('Desktop'); $lnk = $ws.CreateShortcut((Join-Path $desktop 'MeiqiaWshotoBridge.lnk')); $quote = [char]34; $argsValue = ''; if ('%SCRIPT%' -ne '') { $argsValue = $quote + '%SCRIPT%' + $quote }; $lnk.TargetPath = '%TARGET%'; $lnk.Arguments = $argsValue; $lnk.WorkingDirectory = '%WORKDIR%'; $lnk.IconLocation = '%ICON%'; $lnk.Description = '美洽到微盛线索转接控制台'; $lnk.Save()"

if errorlevel 1 (
    echo 创建桌面快捷方式失败，请右键手动发送 start_control_panel.bat 到桌面。
) else (
    echo 已创建桌面快捷方式：MeiqiaWshotoBridge
)
pause
