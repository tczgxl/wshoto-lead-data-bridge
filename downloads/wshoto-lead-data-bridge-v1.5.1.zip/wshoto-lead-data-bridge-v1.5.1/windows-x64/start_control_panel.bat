@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "PYTHONUTF8=1"

if exist "%~dp0MeiqiaWshotoBridge.exe" (
    start "" "%~dp0MeiqiaWshotoBridge.exe"
    exit /b 0
)

if exist "%~dp0pythonw.exe" (
    start "" "%~dp0pythonw.exe" "%~dp0control_panel.py"
    exit /b 0
)

set "PYTHON_CHECK="
where py >nul 2>nul
if not errorlevel 1 set "PYTHON_CHECK=py -3"
if not defined PYTHON_CHECK (
    where python >nul 2>nul
    if not errorlevel 1 set "PYTHON_CHECK=python"
)
if defined PYTHON_CHECK (
    %PYTHON_CHECK% -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >nul 2>nul
    if errorlevel 1 (
        echo Python 版本过低或不可用，需要 3.10 或更高版本。
        %PYTHON_CHECK% --version
        pause
        exit /b 1
    )
)

set "PYTHON_CMD="
where pyw >nul 2>nul
if not errorlevel 1 set "PYTHON_CMD=pyw -3"
if not defined PYTHON_CMD (
    where pythonw >nul 2>nul
    if not errorlevel 1 set "PYTHON_CMD=pythonw"
)
if not defined PYTHON_CMD (
    where py >nul 2>nul
    if not errorlevel 1 set "PYTHON_CMD=py -3"
)
if not defined PYTHON_CMD (
    where python >nul 2>nul
    if not errorlevel 1 set "PYTHON_CMD=python"
)
if not defined PYTHON_CMD (
    echo 未找到 Python，请安装 Python 3.10 或更高版本，
    echo 安装时勾选 Add python.exe to PATH。
    pause
    exit /b 1
)

start "" %PYTHON_CMD% control_panel.py
exit /b 0
