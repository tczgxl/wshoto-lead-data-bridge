#!/usr/bin/env python3
"""Windows 桌面控制台：本地网页启停美洽 → 微盛转接服务。"""

from __future__ import annotations

import argparse
import hmac
import json
import logging
import os
import secrets
import shutil
import subprocess
import sys
import tempfile
import threading
import traceback
import urllib.request
import webbrowser
from collections import deque
from datetime import datetime
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlparse, urlsplit, urlunparse

if sys.version_info < (3, 10):
    stream = sys.stderr
    if stream is not None:
        stream.write(
            "需要 Python 3.10 或更高版本，当前版本：%s"
            % sys.version.split()[0]
        )
        stream.write("\n")
    raise SystemExit(2)

from meiqia_bridge.config import Config, ConfigError
from meiqia_bridge.server import BridgeHTTPServer, create_server
from meiqia_bridge.version import __version__


def application_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


APP_DIR = application_dir()

DEFAULT_ENV = """# 由 Windows 控制台自动生成
WSHOTO_CALLBACK_URL=
MEIQIA_WEBHOOK_SECRET=
ALLOW_UNSIGNED_WEBHOOKS=false
HOST=127.0.0.1
PORT=8080
WEBHOOK_PATH=/webhook/meiqia
HEALTH_PATH=/healthz
PUBLIC_BASE_URL=
CONTROL_PORT=8090
AUTO_START_SERVICE=false
WSHOTO_TIMEOUT_SECONDS=8
WSHOTO_MAX_ATTEMPTS=3
CAPTURE_RAW_PAYLOADS=false
SQLITE_PATH=data/bridge.sqlite3
MAX_BODY_BYTES=1048576
LOG_LEVEL=INFO
"""


class MemoryLogHandler(logging.Handler):
    def __init__(self, capacity: int = 300) -> None:
        super().__init__()
        self._lines: deque[str] = deque(maxlen=capacity)
        self._lock = threading.Lock()

    def emit(self, record: logging.LogRecord) -> None:
        try:
            message = self.format(record)
        except Exception:
            message = record.getMessage()
        with self._lock:
            self._lines.append(message)

    def lines(self) -> list[str]:
        with self._lock:
            return list(self._lines)


def read_env_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.is_file():
        return values
    for raw_line in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].lstrip()
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not key:
            continue
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        values[key] = value
    return values


def update_env_file(path: Path, updates: dict[str, str]) -> None:
    lines = (
        path.read_text(encoding="utf-8-sig").splitlines()
        if path.is_file()
        else []
    )
    seen: set[str] = set()
    result: list[str] = []
    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            result.append(line)
            continue
        key = stripped.split("=", 1)[0].strip()
        if key.startswith("export "):
            key = key[7:].strip()
        if key in updates:
            result.append(f"{key}={updates[key]}")
            seen.add(key)
        else:
            result.append(line)
    for key, value in updates.items():
        if key not in seen:
            result.append(f"{key}={value}")

    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text("\n".join(result).rstrip() + "\n", encoding="utf-8")
    try:
        os.chmod(temporary, 0o600)
    except OSError:
        pass
    temporary.replace(path)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def ensure_env_file(app_dir: Path) -> None:
    env_path = app_dir / ".env"
    if env_path.exists():
        return
    example = app_dir / ".env.example"
    if example.is_file():
        shutil.copyfile(example, env_path)
        values = read_env_file(env_path)
        if values.get("HOST") == "0.0.0.0":
            update_env_file(env_path, {"HOST": "127.0.0.1"})
    else:
        env_path.write_text(DEFAULT_ENV, encoding="utf-8")
    try:
        os.chmod(env_path, 0o600)
    except OSError:
        pass


def normalize_base_url(value: str) -> str:
    value = value.strip().rstrip("/")
    if not value:
        return ""
    parsed = urlparse(value)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError("URL 必须是 http:// 或 https:// 开头的完整地址")
    return value


def normalize_webhook_path(value: str) -> str:
    path = value.strip() or "/webhook/meiqia"
    if not path.startswith("/"):
        path = "/" + path
    path = path.rstrip("/") or "/"
    if any(character in path for character in (" ", "?", "#")):
        raise ValueError("Webhook 路径不能包含空格、? 或 #")
    return path


def mask_url(value: str) -> str:
    if not value:
        return ""
    parsed = urlparse(value)
    if not parsed.netloc:
        return value
    parts = parsed.path.rsplit("/", 1)
    if len(parts) == 2 and len(parts[1]) > 12:
        token = parts[1]
        parts[1] = token[:4] + "..." + token[-4:]
        path = "/".join(parts)
    else:
        path = parsed.path
    return urlunparse(
        (parsed.scheme, parsed.netloc, path, parsed.params, parsed.query, parsed.fragment)
    )


def wshoto_url_is_configured(value: str) -> bool:
    return bool(value.strip()) and "REPLACE_WITH_YOUR_TOKEN" not in value


def join_url(base: str, path: str) -> str:
    return base.rstrip("/") + "/" + path.lstrip("/")


def safe_print(message: str, error: bool = False) -> None:
    stream = sys.stderr if error else sys.stdout
    if stream is None:
        return
    try:
        stream.write(message + "\n")
        stream.flush()
    except Exception:
        pass


def probe_control(port: int) -> bool:
    try:
        with urllib.request.urlopen(
            f"http://127.0.0.1:{port}/api/health",
            timeout=1.5,
        ) as response:
            payload = json.loads(response.read())
        return payload.get("app") == "meiqia-wshoto-control"
    except Exception:
        return False


def open_control_window(url: str) -> bool:
    if os.name == "nt":
        candidates: list[str] = []
        for command in ("msedge", "chrome"):
            found = shutil.which(command)
            if found:
                candidates.append(found)
        for variable in ("PROGRAMFILES(X86)", "PROGRAMFILES", "LOCALAPPDATA"):
            base = os.environ.get(variable)
            if not base:
                continue
            candidates.extend(
                [
                    str(
                        Path(base)
                        / "Microsoft"
                        / "Edge"
                        / "Application"
                        / "msedge.exe"
                    ),
                    str(
                        Path(base)
                        / "Google"
                        / "Chrome"
                        / "Application"
                        / "chrome.exe"
                    ),
                ]
            )
        for candidate in candidates:
            if not Path(candidate).is_file():
                continue
            try:
                subprocess.Popen(
                    [candidate, f"--app={url}", "--window-size=1200,920"],
                    close_fds=True,
                )
                return True
            except OSError:
                continue
    try:
        return bool(webbrowser.open(url))
    except Exception:
        return False


def _powershell_quote(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def ensure_desktop_shortcut() -> bool:
    """Create or refresh the Windows desktop shortcut for the portable app."""
    if os.name != "nt":
        return False

    target = Path(sys.executable).resolve()
    if not getattr(sys, "frozen", False) and target.name.lower() == "python.exe":
        windowed_python = target.with_name("pythonw.exe")
        if windowed_python.is_file():
            target = windowed_python
    arguments = ""
    if not getattr(sys, "frozen", False):
        arguments = f'"{Path(__file__).resolve()}"'
    icon = APP_DIR / "assets" / "app.ico"
    icon_value = f"{icon},0" if icon.is_file() else ""
    script = f"""$ErrorActionPreference = 'Stop'
$desktop = [Environment]::GetFolderPath('Desktop')
if (-not $desktop) {{ exit 2 }}
$shortcutPath = Join-Path $desktop 'MeiqiaWshotoBridge.lnk'
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = {_powershell_quote(str(target))}
$shortcut.Arguments = {_powershell_quote(arguments)}
$shortcut.WorkingDirectory = {_powershell_quote(str(APP_DIR))}
$shortcut.IconLocation = {_powershell_quote(icon_value)}
$shortcut.Description = {_powershell_quote("美洽到微盛线索转接控制台")}
$shortcut.Save()
"""
    script_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8-sig",
            suffix=".ps1",
            delete=False,
        ) as temporary:
            temporary.write(script)
            script_path = Path(temporary.name)
        completed = subprocess.run(
            [
                "powershell",
                "-NoProfile",
                "-NonInteractive",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(script_path),
            ],
            cwd=str(APP_DIR),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            timeout=15,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            check=False,
        )
        if completed.returncode != 0:
            detail = completed.stderr.decode(errors="replace").strip()
            logging.getLogger("control_panel").warning(
                "desktop shortcut failed: %s",
                detail or f"exit code {completed.returncode}",
            )
            return False
        return True
    except Exception as exc:
        logging.getLogger("control_panel").warning(
            "desktop shortcut failed: %s",
            exc,
        )
        return False
    finally:
        if script_path is not None:
            try:
                script_path.unlink()
            except OSError:
                pass


class BridgeManager:
    def __init__(self, app_dir: Path, control_port: int) -> None:
        self.app_dir = app_dir
        self.control_port = control_port
        self._lock = threading.RLock()
        self._server: BridgeHTTPServer | None = None
        self._thread: threading.Thread | None = None
        self._config: Config | None = None
        self._started_at: str = ""
        self._last_error: str = ""

    def is_running(self) -> bool:
        with self._lock:
            thread = self._thread
            return bool(thread and thread.is_alive())

    def start(self) -> dict[str, Any]:
        with self._lock:
            if self.is_running():
                raise RuntimeError("服务已在运行")
            values = read_env_file(self.app_dir / ".env")
            config = Config.from_mapping(values, self.app_dir)
            if config.port == self.control_port:
                raise RuntimeError("服务端口不能与控制台端口相同")
            server = create_server(config)
            thread = threading.Thread(
                target=server.serve_forever,
                name="meiqia-bridge",
                daemon=True,
            )
            thread.start()
            self._server = server
            self._thread = thread
            self._config = config
            self._started_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self._last_error = ""
        logging.getLogger("control_panel").info(
            "service started on %s:%s webhook=%s",
            config.host,
            config.port,
            config.webhook_path,
        )
        return self.status()

    def stop(self) -> dict[str, Any]:
        with self._lock:
            server = self._server
            thread = self._thread
            self._server = None
            self._thread = None
            self._config = None
            self._started_at = ""
        if server is None:
            return self.status()
        try:
            if thread and thread.is_alive():
                server.shutdown()
                thread.join(timeout=5)
            server.server_close()
            server.app.store.close()
        except Exception:
            logging.getLogger("control_panel").exception("failed to stop service")
        logging.getLogger("control_panel").info("service stopped")
        return self.status()

    def status(self) -> dict[str, Any]:
        values = read_env_file(self.app_dir / ".env")
        running = self.is_running()
        config = self._config
        host = config.host if config else values.get("HOST", "127.0.0.1")
        try:
            port = config.port if config else int(values.get("PORT", "8080"))
        except ValueError:
            port = 0
        webhook_path = (
            config.webhook_path
            if config
            else normalize_webhook_path(values.get("WEBHOOK_PATH", "/webhook/meiqia"))
        )
        public_url = values.get("PUBLIC_BASE_URL", "").strip().rstrip("/")
        wshoto_url = values.get("WSHOTO_CALLBACK_URL", "").strip()
        wshoto_configured = wshoto_url_is_configured(wshoto_url)
        secret_set = bool(values.get("MEIQIA_WEBHOOK_SECRET", "").strip())
        allow_unsigned = values.get("ALLOW_UNSIGNED_WEBHOOKS", "").lower() in {
            "1",
            "true",
            "yes",
            "y",
            "on",
        }
        local_base = f"http://127.0.0.1:{port}" if port else ""
        local_webhook_url = (
            join_url(local_base, webhook_path) if local_base else ""
        )
        public_webhook_url = (
            join_url(public_url, webhook_path) if public_url else ""
        )
        return {
            "running": running,
            "host": host,
            "port": port,
            "webhook_path": webhook_path,
            "local_webhook_url": local_webhook_url,
            "public_url": public_url,
            "public_webhook_url": public_webhook_url,
            "wshoto_url_set": wshoto_configured,
            "wshoto_url_masked": mask_url(wshoto_url) if wshoto_configured else "",
            "secret_set": secret_set,
            "allow_unsigned": allow_unsigned,
            "config_ready": bool(
                wshoto_configured
                and (secret_set or allow_unsigned)
            ),
            "started_at": self._started_at,
            "last_error": self._last_error,
        }

    def config_view(self) -> dict[str, Any]:
        values = read_env_file(self.app_dir / ".env")
        wshoto_url = values.get("WSHOTO_CALLBACK_URL", "").strip()
        wshoto_configured = wshoto_url_is_configured(wshoto_url)
        try:
            port = int(values.get("PORT", "8080"))
        except ValueError:
            port = 8080
        return {
            "public_url": values.get("PUBLIC_BASE_URL", "").strip().rstrip("/"),
            "wshoto_url_set": wshoto_configured,
            "wshoto_url_masked": mask_url(wshoto_url) if wshoto_configured else "",
            "secret_set": bool(values.get("MEIQIA_WEBHOOK_SECRET", "").strip()),
            "allow_unsigned": values.get("ALLOW_UNSIGNED_WEBHOOKS", "").lower()
            in {"1", "true", "yes", "y", "on"},
            "host": values.get("HOST", "127.0.0.1") or "127.0.0.1",
            "port": port,
            "webhook_path": values.get("WEBHOOK_PATH", "/webhook/meiqia")
            or "/webhook/meiqia",
            "auto_start": values.get("AUTO_START_SERVICE", "").lower()
            in {"1", "true", "yes", "y", "on"},
        }

    def save_config(self, payload: dict[str, Any]) -> dict[str, Any]:
        if self.is_running():
            raise RuntimeError("请先关闭服务，再修改配置")
        values = read_env_file(self.app_dir / ".env")
        public_url = normalize_base_url(str(payload.get("public_url", "")))
        webhook_path = normalize_webhook_path(
            str(payload.get("webhook_path", "/webhook/meiqia"))
        )
        try:
            port = int(payload.get("port", 8080))
        except (TypeError, ValueError) as exc:
            raise ValueError("本地端口必须是整数") from exc
        if not 1 <= port <= 65535:
            raise ValueError("本地端口必须在 1 到 65535 之间")
        if port == self.control_port:
            raise ValueError("服务端口不能与控制台端口相同")

        host = str(payload.get("host", "127.0.0.1")).strip() or "127.0.0.1"
        if host not in {"127.0.0.1", "0.0.0.0"}:
            raise ValueError("监听地址只能是 127.0.0.1 或 0.0.0.0")

        wshoto_url = str(payload.get("wshoto_url", "")).strip()
        if wshoto_url:
            wshoto_url = normalize_base_url(wshoto_url)
        else:
            wshoto_url = values.get("WSHOTO_CALLBACK_URL", "").strip()
        if not wshoto_url:
            raise ValueError("请填写微盛 Webhook 地址")
        if "REPLACE_WITH_YOUR_TOKEN" in wshoto_url:
            raise ValueError("微盛 Webhook 地址仍是示例占位符")

        incoming_secret = str(payload.get("meiqia_secret", "")).strip()
        if payload.get("clear_secret"):
            secret = ""
        elif incoming_secret:
            secret = incoming_secret
        else:
            secret = values.get("MEIQIA_WEBHOOK_SECRET", "").strip()
        allow_unsigned = bool(payload.get("allow_unsigned", False))
        if not secret and not allow_unsigned:
            raise ValueError(
                "请填写美洽 Webhook 密钥，或勾选“允许无签名请求（仅联调）”"
            )
        auto_start = bool(payload.get("auto_start", False))

        updates = {
            "WSHOTO_CALLBACK_URL": wshoto_url,
            "MEIQIA_WEBHOOK_SECRET": secret,
            "ALLOW_UNSIGNED_WEBHOOKS": "true" if allow_unsigned else "false",
            "HOST": host,
            "PORT": str(port),
            "WEBHOOK_PATH": webhook_path,
            "PUBLIC_BASE_URL": public_url,
            "AUTO_START_SERVICE": "true" if auto_start else "false",
        }
        update_env_file(self.app_dir / ".env", updates)
        logging.getLogger("control_panel").info("configuration saved")
        return self.status()

    def record_error(self, message: str) -> None:
        self._last_error = message[:500]


class ControlHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = os.name != "nt"

    def __init__(
        self,
        server_address: tuple[str, int],
        manager: BridgeManager,
        token: str,
    ) -> None:
        self.manager = manager
        self.token = token
        super().__init__(server_address, ControlHandler)


class ControlHandler(BaseHTTPRequestHandler):
    server_version = f"MeiqiaWshotoControl/{__version__}"

    @property
    def control(self) -> ControlHTTPServer:
        return self.server  # type: ignore[return-value]

    def do_GET(self) -> None:
        path = urlsplit(self.path).path
        if path == "/":
            self._send_html(INDEX_PAGE)
            return
        if path == "/api/health":
            self._send_json(HTTPStatus.OK, {"status": "ok", "app": "meiqia-wshoto-control"})
            return
        if not self._authorized():
            return
        if path == "/api/status":
            self._send_json(HTTPStatus.OK, self.control.manager.status())
            return
        if path == "/api/config":
            self._send_json(HTTPStatus.OK, self.control.manager.config_view())
            return
        if path == "/api/logs":
            handler = getattr(self.server, "memory_handler", None)
            lines = handler.lines() if handler else []
            self._send_json(HTTPStatus.OK, {"lines": lines})
            return
        self._send_json(
            HTTPStatus.NOT_FOUND,
            {"code": HTTPStatus.NOT_FOUND, "message": "not found"},
        )

    def do_POST(self) -> None:
        path = urlsplit(self.path).path
        if not self._authorized():
            return
        if path == "/api/start":
            self._handle_start()
            return
        if path == "/api/stop":
            self._handle_stop()
            return
        if path == "/api/config":
            self._handle_config()
            return
        if path == "/api/quit":
            self._handle_quit()
            return
        self._send_json(
            HTTPStatus.NOT_FOUND,
            {"code": HTTPStatus.NOT_FOUND, "message": "not found"},
        )

    def _handle_start(self) -> None:
        try:
            status = self.control.manager.start()
        except (ConfigError, RuntimeError, OSError, ValueError) as exc:
            self.control.manager.record_error(str(exc))
            logging.getLogger("control_panel").warning("start failed: %s", exc)
            self._send_json(
                HTTPStatus.BAD_REQUEST,
                {"ok": False, "message": str(exc)},
            )
            return
        except Exception as exc:
            self.control.manager.record_error(f"{type(exc).__name__}: {exc}")
            logging.getLogger("control_panel").exception("unexpected start error")
            self._send_json(
                HTTPStatus.INTERNAL_SERVER_ERROR,
                {"ok": False, "message": f"启动失败：{type(exc).__name__}: {exc}"},
            )
            return
        self._send_json(HTTPStatus.OK, {"ok": True, "status": status})

    def _handle_stop(self) -> None:
        try:
            status = self.control.manager.stop()
        except Exception as exc:
            logging.getLogger("control_panel").exception("unexpected stop error")
            self._send_json(
                HTTPStatus.INTERNAL_SERVER_ERROR,
                {"ok": False, "message": f"关闭失败：{type(exc).__name__}: {exc}"},
            )
            return
        self._send_json(HTTPStatus.OK, {"ok": True, "status": status})

    def _handle_config(self) -> None:
        try:
            payload = self._read_json()
            status = self.control.manager.save_config(payload)
        except (ConfigError, RuntimeError, ValueError) as exc:
            self._send_json(
                HTTPStatus.BAD_REQUEST,
                {"ok": False, "message": str(exc)},
            )
            return
        except Exception as exc:
            logging.getLogger("control_panel").exception("unexpected config error")
            self._send_json(
                HTTPStatus.INTERNAL_SERVER_ERROR,
                {"ok": False, "message": f"保存失败：{type(exc).__name__}: {exc}"},
            )
            return
        self._send_json(HTTPStatus.OK, {"ok": True, "status": status})

    def _handle_quit(self) -> None:
        try:
            self.control.manager.stop()
        finally:
            try:
                self._send_json(
                    HTTPStatus.OK,
                    {"ok": True, "message": "控制台已退出"},
                )
            finally:
                threading.Thread(
                    target=self.control.shutdown,
                    name="control-shutdown",
                    daemon=True,
                ).start()

    def _read_json(self) -> dict[str, Any]:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError as exc:
            raise ValueError("Content-Length 无效") from exc
        if length <= 0 or length > 65536:
            raise ValueError("请求体为空或过大")
        raw = self.rfile.read(length)
        try:
            payload = json.loads(raw)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("请求体必须是 JSON") from exc
        if not isinstance(payload, dict):
            raise ValueError("请求体必须是 JSON 对象")
        return payload

    def _authorized(self) -> bool:
        received = self.headers.get("X-Control-Token", "")
        if not hmac.compare_digest(received, self.control.token):
            self._send_json(
                HTTPStatus.FORBIDDEN,
                {"ok": False, "message": "控制台令牌无效，请从桌面图标重新打开"},
            )
            return False
        return True

    def _send_html(self, html: str) -> None:
        body = html.encode("utf-8")
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _send_json(self, status: int, payload: dict[str, Any]) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(int(status))
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt: str, *args: Any) -> None:
        logging.getLogger("control_panel").debug(
            "%s - %s",
            self.address_string(),
            fmt % args,
        )


def setup_logging(app_dir: Path) -> MemoryLogHandler:
    data_dir = app_dir / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(data_dir, 0o700)
    except OSError:
        pass

    memory = MemoryLogHandler()
    formatter = logging.Formatter(
        "%(asctime)s %(levelname)s %(message)s",
        datefmt="%H:%M:%S",
    )
    memory.setFormatter(formatter)

    root = logging.getLogger()
    root.setLevel(logging.INFO)
    for handler in list(root.handlers):
        root.removeHandler(handler)
    root.addHandler(memory)

    file_handler = logging.FileHandler(
        app_dir / "data" / "control-panel.log",
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)
    root.addHandler(file_handler)

    if sys.stderr is not None:
        console = logging.StreamHandler()
        console.setFormatter(formatter)
        root.addHandler(console)
    return memory


def write_token(app_dir: Path, token: str) -> None:
    data_dir = app_dir / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    path = data_dir / "control-token.txt"
    path.write_text(token, encoding="utf-8")
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def read_token(app_dir: Path) -> str:
    path = app_dir / "data" / "control-token.txt"
    try:
        return path.read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def remove_token(app_dir: Path) -> None:
    try:
        (app_dir / "data" / "control-token.txt").unlink()
    except OSError:
        pass


def show_message(title: str, message: str, error: bool = True) -> None:
    if os.name == "nt":
        try:
            import ctypes

            icon = 0x10 if error else 0x40
            ctypes.windll.user32.MessageBoxW(None, message, title, icon)
            return
        except Exception:
            pass
    safe_print(f"{title}: {message}", error=True)


def main() -> int:
    parser = argparse.ArgumentParser(description="美洽 → 微盛线索转接 Windows 控制台")
    parser.add_argument("--no-browser", action="store_true", help="不自动打开浏览器")
    parser.add_argument("--control-port", type=int, default=0, help="控制台端口")
    args = parser.parse_args()

    ensure_env_file(APP_DIR)
    memory = setup_logging(APP_DIR)
    if os.name == "nt" and ensure_desktop_shortcut():
        logging.getLogger("control_panel").info(
            "desktop shortcut is ready: MeiqiaWshotoBridge.lnk"
        )
    values = read_env_file(APP_DIR / ".env")
    try:
        control_port = args.control_port or int(values.get("CONTROL_PORT", "8090"))
    except ValueError:
        control_port = 8090

    token = secrets.token_urlsafe(24)
    manager = BridgeManager(APP_DIR, control_port)
    if probe_control(control_port):
        existing_token = read_token(APP_DIR)
        if existing_token:
            url = f"http://127.0.0.1:{control_port}/?token={existing_token}"
            if not args.no_browser:
                open_control_window(url)
            safe_print(f"控制台已在运行：{url}")
            return 0
        message = (
            "控制台已在运行，但找不到控制令牌文件。\n"
            "请关闭已有的控制台进程后重试。"
        )
        show_message("控制台已在运行", message)
        return 1
    try:
        server = ControlHTTPServer(("127.0.0.1", control_port), manager, token)
    except OSError as exc:
        existing_token = read_token(APP_DIR)
        if existing_token:
            url = f"http://127.0.0.1:{control_port}/?token={existing_token}"
            if not args.no_browser:
                webbrowser.open(url)
            safe_print(f"控制台已在运行：{url}")
            return 0
        message = (
            f"控制台端口 {control_port} 被占用，无法启动。\n"
            f"请关闭占用该端口的程序，或修改 .env 的 CONTROL_PORT。\n\n{exc}"
        )
        logging.getLogger("control_panel").error(message)
        show_message("启动失败", message)
        return 1

    server.memory_handler = memory  # type: ignore[attr-defined]
    write_token(APP_DIR, token)
    auto_start = values.get("AUTO_START_SERVICE", "").lower() in {
        "1",
        "true",
        "yes",
        "y",
        "on",
    }
    if auto_start and manager.status()["config_ready"]:
        try:
            manager.start()
            logging.getLogger("control_panel").info("auto-start enabled")
        except Exception as exc:
            manager.record_error(str(exc))
            logging.getLogger("control_panel").warning(
                "auto-start failed: %s",
                exc,
            )
    url = f"http://127.0.0.1:{control_port}/?token={token}"
    logging.getLogger("control_panel").info(
        "control panel listening on http://127.0.0.1:%s",
        control_port,
    )
    if not args.no_browser:
        opened = open_control_window(url)
        if not opened:
            show_message(
                "控制台已启动",
                f"浏览器没有自动打开，请手动访问：\n{url}",
                error=False,
            )
    safe_print(f"控制台已启动：{url}")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        manager.stop()
        server.server_close()
        remove_token(APP_DIR)
        logging.getLogger("control_panel").info("control panel stopped")
    return 0


INDEX_HTML = r"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>美洽 → 微盛 线索转接</title>
<style>
:root {
  --bg: #f3f6fb;
  --card: #ffffff;
  --ink: #172033;
  --muted: #667085;
  --line: #e4e9f2;
  --primary: #0f766e;
  --primary-deep: #115e59;
  --primary-soft: #e6f5f2;
  --danger: #b42318;
  --danger-soft: #fff1f0;
  --shadow: 0 12px 34px rgba(23, 32, 51, .08);
}
* { box-sizing: border-box; }
body {
  margin: 0;
  background: radial-gradient(circle at 8% 0%, #e4f4f1 0, transparent 32%), var(--bg);
  color: var(--ink);
  font: 14px/1.55 -apple-system, BlinkMacSystemFont, "Segoe UI", "Microsoft YaHei", sans-serif;
}
.app { max-width: 1080px; margin: 0 auto; padding: 34px 22px 48px; }
.hero { display: flex; justify-content: space-between; gap: 18px; align-items: flex-start; margin-bottom: 22px; }
.eyebrow { color: var(--primary); font-size: 11px; font-weight: 800; letter-spacing: .18em; }
h1 { margin: 5px 0 4px; font-size: 28px; letter-spacing: -.03em; }
h2 { margin: 0 0 14px; font-size: 15px; }
.sub { margin: 0; color: var(--muted); }
.pill { border-radius: 999px; padding: 8px 14px; font-size: 12px; font-weight: 800; white-space: nowrap; }
.pill.stopped { color: #475467; background: #e9edf5; }
.pill.running { color: #087443; background: #dcfae6; }
.card { background: var(--card); border: 1px solid var(--line); border-radius: 18px; padding: 20px; box-shadow: var(--shadow); }
.actions { display: flex; justify-content: space-between; align-items: center; gap: 18px; margin-bottom: 16px; }
.actions h2 { margin-bottom: 3px; }
.actions p { margin: 0; color: var(--muted); }
.buttons { display: flex; gap: 10px; }
.btn { border: 0; border-radius: 11px; padding: 10px 16px; font: inherit; font-weight: 700; cursor: pointer; transition: .15s ease; }
.btn:disabled { opacity: .45; cursor: not-allowed; }
.btn.primary { color: #fff; background: var(--primary); }
.btn.primary:hover:not(:disabled) { background: var(--primary-deep); }
.btn.danger { color: var(--danger); background: var(--danger-soft); }
.btn.danger:hover:not(:disabled) { background: #ffe0dc; }
.btn.secondary { color: var(--primary-deep); background: var(--primary-soft); margin-top: 4px; }
.btn.ghost { color: var(--primary-deep); background: #f8fbfa; border: 1px solid var(--line); }
.btn.small { padding: 7px 11px; font-size: 12px; }
.grid { display: grid; grid-template-columns: 1.1fr .9fr; gap: 16px; margin-bottom: 16px; }
label { display: block; color: #344054; font-size: 12px; font-weight: 700; margin-bottom: 13px; }
input, select {
  display: block; width: 100%; margin-top: 6px; border: 1px solid var(--line);
  border-radius: 10px; padding: 10px 11px; color: var(--ink); background: #fbfcfe;
  font: inherit; outline: none;
}
input:focus, select:focus { border-color: #73b8ae; box-shadow: 0 0 0 3px rgba(15,118,110,.10); }
input[readonly] { color: #475467; background: #f5f7fb; }
small { display: block; margin-top: 5px; color: var(--muted); font-weight: 400; line-height: 1.45; }
.input-row { display: flex; gap: 8px; align-items: stretch; }
.input-row input { flex: 1; }
.input-row .btn { margin-top: 6px; white-space: nowrap; }
.two { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
.check { display: flex; align-items: center; gap: 9px; margin: 2px 0 14px; }
.check input { width: auto; margin: 0; }
fieldset { border: 0; padding: 0; margin: 0; min-width: 0; }
fieldset:disabled { opacity: .72; }
details { margin: 2px 0 12px; border-top: 1px dashed var(--line); padding-top: 12px; }
summary { cursor: pointer; color: var(--primary-deep); font-weight: 700; margin-bottom: 10px; }
.copy-row { display: flex; gap: 9px; }
.copy-row input { flex: 1; }
.stat-row { display: grid; grid-template-columns: 1fr; gap: 8px; margin-top: 16px; }
.stat-row div {
  display: flex; justify-content: space-between; align-items: baseline; gap: 14px;
  background: #f8fafc; border: 1px solid var(--line); border-radius: 12px; padding: 11px;
}
.stat-row span { color: var(--muted); font-size: 11px; white-space: nowrap; }
.stat-row strong { font-size: 11px; text-align: right; overflow-wrap: anywhere; }
.steps { margin-top: 22px; padding-top: 16px; border-top: 1px dashed var(--line); }
.steps h3 { margin: 0 0 10px; font-size: 13px; }
.steps ol { margin: 0; padding-left: 20px; color: #475467; }
.steps li { margin: 7px 0; }
.hint { margin: 5px 0 0; color: var(--muted); font-size: 12px; }
.logs { margin-bottom: 16px; }
.logs-head { display: flex; justify-content: space-between; align-items: center; }
.logs-head h2 { margin: 0; }
pre {
  margin: 12px 0 0; min-height: 150px; max-height: 300px; overflow: auto;
  padding: 13px; border-radius: 12px; background: #111827; color: #d7e3f4;
  font: 12px/1.55 ui-monospace, SFMono-Regular, Consolas, monospace; white-space: pre-wrap;
}
footer { display: flex; gap: 14px; align-items: center; color: var(--muted); font-size: 12px; }
footer .ver { margin-left: auto; opacity: .65; }
.link { border: 0; background: none; padding: 0; font: inherit; cursor: pointer; text-decoration: underline; }
.danger-link { color: var(--danger); }
.toast {
  position: fixed; left: 50%; bottom: 24px; transform: translate(-50%, 18px);
  background: #172033; color: #fff; padding: 11px 16px; border-radius: 10px;
  opacity: 0; pointer-events: none; transition: .2s ease; max-width: 90vw;
}
.toast.show { opacity: 1; transform: translate(-50%, 0); }
.toast.error { background: #8f1d14; }
@media (max-width: 760px) {
  .app { padding: 22px 14px 36px; }
  .hero, .actions { flex-direction: column; align-items: stretch; }
  .grid, .two { grid-template-columns: 1fr; }
  .buttons { justify-content: stretch; }
  .buttons .btn { flex: 1; }
}
</style>
</head>
<body>
<div class="app">
  <header class="hero">
    <div>
      <div class="eyebrow">LEAD BRIDGE · WINDOWS CONTROL</div>
      <h1>美洽 → 微盛 线索转接</h1>
      <p class="sub">本地控制台。关闭浏览器不会停止服务，再次双击桌面图标可重新打开。</p>
    </div>
    <div id="statusPill" class="pill stopped">已停止</div>
  </header>

  <section class="card actions">
    <div>
      <h2>服务控制</h2>
      <p id="statusText">服务未启动</p>
    </div>
    <div class="buttons">
      <button id="startBtn" class="btn primary" type="button">启用服务</button>
      <button id="stopBtn" class="btn danger" type="button" disabled>关闭服务</button>
    </div>
  </section>

  <div class="grid">
    <section class="card">
      <fieldset id="configFields">
        <h2>连接配置</h2>
        <label>公网 URL
          <input id="publicUrl" placeholder="https://lead.example.com">
          <small>客户的美洽后台需要访问这个地址。没有公网映射时先留空。</small>
        </label>
        <label>微盛 Webhook 地址
          <div class="input-row">
            <input id="wshotoUrl" type="password" placeholder="已设置，留空不修改">
            <button type="button" class="btn ghost small" id="toggleWshoto">显示</button>
          </div>
          <small id="wshotoHint">从微盛“自定义广告平台”第二步复制完整接收地址。</small>
        </label>
        <label>美洽 Webhook 密钥
          <input id="meiqiaSecret" type="password" placeholder="已设置，留空不修改">
          <small>必须与美洽后台自定义 Webhook 的密钥完全一致。</small>
        </label>
        <label class="check">
          <input id="allowUnsigned" type="checkbox">
          <span>允许无签名请求（仅联调，不建议生产使用）</span>
        </label>
        <label class="check">
          <input id="autoStart" type="checkbox">
          <span>打开控制台时自动启用服务（适合放进启动文件夹）</span>
        </label>

        <h2 style="margin-top:4px">运行参数</h2>
        <div class="two">
          <label>本地端口<input id="port" type="number" min="1" max="65535"></label>
          <label>监听地址
            <select id="host">
              <option value="127.0.0.1">127.0.0.1（仅本机）</option>
              <option value="0.0.0.0">0.0.0.0（局域网/容器）</option>
            </select>
          </label>
        </div>
        <label>Webhook 路径<input id="webhookPath" placeholder="/webhook/meiqia"></label>
        <p class="hint">转发规则：美洽原始 JSON 全量摊平到第一层后直接转发，不做姓名、手机号或其他字段映射。</p>
        <button id="saveBtn" class="btn secondary" type="button">保存配置</button>
        <p class="hint" id="configHint">修改配置前请先关闭服务。</p>
      </fieldset>
    </section>

    <section class="card">
      <h2>给美洽后台填写</h2>
      <div class="copy-row">
        <input id="meiqiaUrl" readonly placeholder="配置公网 URL 后自动生成">
        <button class="btn ghost" id="copyMeiqia" type="button">复制</button>
      </div>
      <p class="hint">美洽自定义 Webhook → URL；方法选 POST，密钥与上方一致。</p>

      <div class="stat-row">
        <div><span>本机监听</span><strong id="localUrl">-</strong></div>
        <div><span>微盛地址</span><strong id="wshotoMasked">未设置</strong></div>
        <div><span>启动时间</span><strong id="startedAt">-</strong></div>
      </div>
      <p class="hint" id="publicHint"></p>
      <div class="steps">
        <h3>上线三步</h3>
        <ol>
          <li>填写左侧配置，点击「保存配置」。</li>
          <li>点击「启用服务」，状态变为“运行中”。</li>
          <li>把上方地址填到美洽自定义 Webhook。</li>
        </ol>
        <p class="hint">公网 HTTPS 仍需 Cloudflare Tunnel 或 Nginx 指向本机服务端口。</p>
      </div>
    </section>
  </div>

  <section class="card logs">
    <div class="logs-head">
      <h2>运行日志</h2>
      <button class="btn ghost small" id="refreshLogs" type="button">刷新</button>
    </div>
    <pre id="logs">等待服务启动...</pre>
  </section>

  <footer>
    <button class="link danger-link" id="quitBtn" type="button">退出控制台</button>
    <span>退出控制台会停止服务；仅关闭浏览器不会。</span>
    <span class="ver">v{{VERSION}}</span>
  </footer>
</div>
<div id="toast" class="toast"></div>
<script>
const token = new URLSearchParams(location.search).get('token') || '';
const $ = (id) => document.getElementById(id);
let running = false;
let toastTimer = 0;

function toast(message, error = false) {
  const node = $('toast');
  node.textContent = message;
  node.className = 'toast show' + (error ? ' error' : '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { node.className = 'toast'; }, 3200);
}

function headers() {
  return { 'Content-Type': 'application/json', 'X-Control-Token': token };
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    headers: { ...headers(), ...(options.headers || {}) },
  });
  let data = {};
  try { data = await response.json(); } catch (error) { data = {}; }
  if (!response.ok) {
    throw new Error(data.message || ('请求失败：HTTP ' + response.status));
  }
  return data;
}

function setRunning(value) {
  running = value;
  $('statusPill').textContent = value ? '运行中' : '已停止';
  $('statusPill').className = 'pill ' + (value ? 'running' : 'stopped');
  $('startBtn').disabled = value;
  $('stopBtn').disabled = !value;
  $('configFields').disabled = value;
  $('configHint').textContent = value
    ? '服务运行中，修改配置前请先关闭服务。'
    : '修改后点击“保存配置”，再启用服务。';
}

function applyStatus(status) {
  setRunning(Boolean(status.running));
  $('statusText').textContent = status.running
    ? '服务运行中，正在接收 Webhook。'
    : (status.config_ready ? '配置已就绪，点击“启用服务”开始接收。' : '请先填写微盛 Webhook 地址和美洽密钥。');
  $('localUrl').textContent = status.local_webhook_url || '-';
  $('wshotoMasked').textContent = status.wshoto_url_masked || '未设置';
  $('startedAt').textContent = status.started_at || '-';
  $('meiqiaUrl').value = status.public_webhook_url || status.local_webhook_url || '';
  $('publicHint').textContent = status.public_url
    ? ''
    : '公网 URL 未配置：上面显示的是本机地址，美洽云端无法访问。请先配置 Cloudflare Tunnel 或 Nginx。';
  if (status.last_error) {
    $('statusText').textContent = '上次操作失败：' + status.last_error;
  }
}

async function refreshStatus() {
  try {
    const status = await api('/api/status');
    applyStatus(status);
  } catch (error) {
    $('statusText').textContent = error.message;
    if (error.message.includes('令牌')) {
      toast('请从桌面图标重新打开控制台', true);
    }
  }
}

async function loadConfig() {
  const config = await api('/api/config');
  $('publicUrl').value = config.public_url || '';
  $('wshotoUrl').value = '';
  $('wshotoUrl').placeholder = config.wshoto_url_set ? '已设置，留空不修改' : '请填写微盛接收地址';
  $('wshotoHint').textContent = config.wshoto_url_set
    ? '已设置：' + config.wshoto_url_masked + '（留空不修改）'
    : '从微盛“自定义广告平台”第二步复制完整接收地址。';
  $('meiqiaSecret').value = '';
  $('meiqiaSecret').placeholder = config.secret_set ? '已设置，留空不修改' : '请填写美洽 Webhook 密钥';
  $('allowUnsigned').checked = Boolean(config.allow_unsigned);
  $('autoStart').checked = Boolean(config.auto_start);
  $('port').value = config.port;
  $('host').value = config.host === '0.0.0.0' ? '0.0.0.0' : '127.0.0.1';
  $('webhookPath').value = config.webhook_path;
}

async function saveConfig() {
  try {
    await api('/api/config', {
      method: 'POST',
      body: JSON.stringify({
        public_url: $('publicUrl').value,
        wshoto_url: $('wshotoUrl').value,
        meiqia_secret: $('meiqiaSecret').value,
        allow_unsigned: $('allowUnsigned').checked,
        auto_start: $('autoStart').checked,
        host: $('host').value,
        port: Number($('port').value),
        webhook_path: $('webhookPath').value,
      }),
    });
    toast('配置已保存');
    await loadConfig();
    await refreshStatus();
  } catch (error) {
    toast(error.message, true);
  }
}

async function startService() {
  $('startBtn').disabled = true;
  try {
    await api('/api/start', { method: 'POST', body: '{}' });
    toast('服务已启用');
  } catch (error) {
    toast(error.message, true);
  }
  await refreshStatus();
}

async function stopService() {
  $('stopBtn').disabled = true;
  try {
    await api('/api/stop', { method: 'POST', body: '{}' });
    toast('服务已关闭');
  } catch (error) {
    toast(error.message, true);
  }
  await refreshStatus();
}

async function refreshLogs() {
  try {
    const data = await api('/api/logs');
    const node = $('logs');
    node.textContent = (data.lines || []).join('\n') || '暂无日志';
    node.scrollTop = node.scrollHeight;
  } catch (error) {
    $('logs').textContent = error.message;
  }
}

async function copyText(value) {
  if (!value) { toast('没有可复制的内容', true); return; }
  try {
    await navigator.clipboard.writeText(value);
    toast('已复制');
  } catch (error) {
    const input = $('meiqiaUrl');
    input.value = value;
    input.select();
    document.execCommand('copy');
    toast('已复制');
  }
}

async function quitApp() {
  if (!confirm('退出控制台会同时停止服务，确定继续吗？')) return;
  try {
    await api('/api/quit', { method: 'POST', body: '{}' });
    toast('控制台已退出，可以关闭本页');
    $('startBtn').disabled = true;
    $('stopBtn').disabled = true;
  } catch (error) {
    toast(error.message, true);
  }
}

$('startBtn').addEventListener('click', startService);
$('stopBtn').addEventListener('click', stopService);
$('saveBtn').addEventListener('click', saveConfig);
$('refreshLogs').addEventListener('click', refreshLogs);
$('copyMeiqia').addEventListener('click', () => copyText($('meiqiaUrl').value));
$('quitBtn').addEventListener('click', quitApp);
$('toggleWshoto').addEventListener('click', () => {
  const input = $('wshotoUrl');
  input.type = input.type === 'password' ? 'text' : 'password';
  $('toggleWshoto').textContent = input.type === 'password' ? '显示' : '隐藏';
});

if (!token) {
  $('statusText').textContent = '缺少控制台令牌，请从桌面图标重新打开。';
  toast('缺少控制台令牌，请从桌面图标重新打开', true);
} else {
  loadConfig().catch((error) => toast(error.message, true));
  refreshStatus();
  refreshLogs();
  setInterval(refreshStatus, 2500);
  setInterval(refreshLogs, 2500);
}
</script>
</body>
</html>
"""

INDEX_PAGE = INDEX_HTML.replace("{{VERSION}}", __version__)


def run() -> int:
    """Entry point that never dies silently.

    The desktop shortcut starts this module with pythonw.exe, which has no
    console. Without this guard a startup crash leaves the customer staring at
    a window that never opens, with no message anywhere.
    """
    try:
        return main()
    except SystemExit:
        raise
    except BaseException as exc:
        detail = traceback.format_exc()
        logging.getLogger("control_panel").error(
            "control panel crashed: %s", detail
        )
        show_message(
            "控制台启动失败",
            "{0}: {1}\n\n"
            "日志文件：{2}\n\n"
            "{3}".format(
                type(exc).__name__,
                exc,
                APP_DIR / "data" / "control-panel.log",
                detail[-1200:],
            ),
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(run())
