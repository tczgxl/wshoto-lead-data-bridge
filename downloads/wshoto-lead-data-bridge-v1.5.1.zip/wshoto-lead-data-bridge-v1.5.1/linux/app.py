from __future__ import annotations

import sys

if sys.version_info < (3, 10):
    print(
        "需要 Python 3.10 或更高版本，当前版本：%s" % sys.version.split()[0],
        file=sys.stderr,
    )
    raise SystemExit(2)

import logging
import signal
import threading
from pathlib import Path

from meiqia_bridge.config import Config, ConfigError, load_dotenv
from meiqia_bridge.server import create_server


def main() -> int:
    base_dir = Path(__file__).resolve().parent
    load_dotenv(base_dir / ".env")

    try:
        config = Config.from_env(base_dir)
    except ConfigError as exc:
        print(f"配置错误: {exc}", file=sys.stderr)
        return 2

    logging.basicConfig(
        level=getattr(logging, config.log_level, logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )

    server = create_server(config)

    logger = logging.getLogger("meiqia_bridge")
    logger.info(
        "listening on %s:%s webhook_path=%s signature_enabled=%s",
        config.host,
        config.port,
        config.webhook_path,
        bool(config.meiqia_webhook_secret),
    )

    stop_event = threading.Event()
    server_thread = threading.Thread(
        target=server.serve_forever,
        name="http-server",
        daemon=True,
    )
    server_thread.start()

    def request_shutdown(_signum: int, _frame: object) -> None:
        stop_event.set()

    signal.signal(signal.SIGINT, request_shutdown)
    signal.signal(signal.SIGTERM, request_shutdown)

    try:
        stop_event.wait()
    except KeyboardInterrupt:
        pass
    finally:
        logger.info("stopping server")
        server.shutdown()
        server.server_close()
        server_thread.join(timeout=5)
        server.app.store.close()  # type: ignore[attr-defined]
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
