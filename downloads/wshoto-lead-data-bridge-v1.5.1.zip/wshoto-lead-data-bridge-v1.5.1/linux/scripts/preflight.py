#!/usr/bin/env python3
"""Machine-readable preflight check for the Meiqia -> Wshoto bridge.

This script answers one question: "is this deployment actually able to receive
leads right now?" It deliberately separates the two legs of the chain, because
they fail for completely different reasons:

    Meiqia cloud  --(public HTTPS)-->  this machine  --(outbound HTTPS)-->  Wshoto

The left leg needs a public entry point (Cloudflare Tunnel, frp, port mapping).
The right leg only needs outbound internet access. ``self_test.py`` only proves
the local plumbing; this script proves the real chain.

Output is JSON on stdout so an agent can act on it without parsing prose.
Exit code is 0 when every blocking check passes, 1 otherwise.

Examples
--------
    python.exe scripts\\preflight.py
    python.exe scripts\\preflight.py --human
    python.exe scripts\\preflight.py --no-probe-webhook
    python.exe scripts\\preflight.py --base-url https://lead.example.com
"""

from __future__ import annotations

import argparse
import hashlib
import json
import socket
import ssl
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from meiqia_bridge.config import Config, ConfigError  # noqa: E402
from meiqia_bridge.version import __version__  # noqa: E402

ERROR = "error"
WARN = "warn"
PROBE_BODY = b'{"event_type":"preflight_probe","channel_name":"preflight"}'


def read_env_file(path: Path) -> dict[str, str]:
    """Mirror control_panel.read_env_file so both read .env the same way."""
    values: dict[str, str] = {}
    if not path.is_file():
        return values
    for raw_line in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].lstrip()
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        if key:
            values[key] = value
    return values


def as_bool(value: str | None, default: bool = False) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "y", "on"}


def http_get_json(url: str, timeout: float) -> tuple[dict[str, Any] | None, str]:
    request = urllib.request.Request(
        url,
        method="GET",
        headers={"Accept": "application/json", "User-Agent": f"bridge-preflight/{__version__}"},
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            payload = json.loads(response.read(8192))
        if not isinstance(payload, dict):
            return None, "response is not a JSON object"
        return payload, ""
    except urllib.error.HTTPError as exc:
        return None, f"HTTP {exc.code}"
    except urllib.error.URLError as exc:
        return None, f"{type(exc).__name__}: {exc.reason}"
    except (socket.timeout, TimeoutError):
        return None, "timeout"
    except json.JSONDecodeError:
        return None, "response is not valid JSON"
    except Exception as exc:  # noqa: BLE001
        return None, f"{type(exc).__name__}: {exc}"


def tcp_tls_probe(url: str, timeout: float) -> tuple[bool, str]:
    """Check the Wshoto host is reachable without sending any lead data."""
    parts = urlsplit(url)
    host = parts.hostname or ""
    if not host:
        return False, "URL has no host"
    port = parts.port or (443 if parts.scheme == "https" else 80)
    try:
        with socket.create_connection((host, port), timeout=timeout) as raw:
            if parts.scheme != "https":
                return True, f"tcp {host}:{port} reachable (plain http)"
            context = ssl.create_default_context()
            with context.wrap_socket(raw, server_hostname=host) as tls:
                return True, f"tls {host}:{port} ok, {tls.version()}"
    except ssl.SSLCertVerificationError as exc:
        return False, f"certificate verification failed: {exc}"
    except socket.gaierror as exc:
        return False, f"DNS lookup failed: {exc}"
    except (socket.timeout, TimeoutError):
        return False, f"connect timeout after {timeout}s"
    except OSError as exc:
        return False, f"{type(exc).__name__}: {exc}"


class Report:
    def __init__(self) -> None:
        self.checks: list[dict[str, Any]] = []

    def add(
        self,
        check_id: str,
        ok: bool,
        detail: str,
        hint: str = "",
        severity: str = ERROR,
    ) -> None:
        self.checks.append(
            {
                "id": check_id,
                "ok": ok,
                "severity": severity,
                "detail": detail,
                "hint": "" if ok else hint,
            }
        )

    def failed(self) -> list[dict[str, Any]]:
        return [c for c in self.checks if not c["ok"] and c["severity"] == ERROR]

    def warnings(self) -> list[dict[str, Any]]:
        return [c for c in self.checks if not c["ok"] and c["severity"] == WARN]

    def as_dict(self) -> dict[str, Any]:
        failed = self.failed()
        hints: list[str] = []
        for check in failed:
            if check["hint"] and check["hint"] not in hints:
                hints.append(check["hint"])
        return {
            "ok": not failed,
            "version": __version__,
            "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "summary": {
                "total": len(self.checks),
                "passed": sum(1 for c in self.checks if c["ok"]),
                "failed": len(failed),
                "warnings": len(self.warnings()),
            },
            "checks": self.checks,
            "next_action": hints[0] if hints else "",
            "next_actions": hints,
        }


def run_checks(
    base_dir: Path,
    timeout: float,
    probe_webhook: bool,
    base_url_override: str,
) -> Report:
    report = Report()

    report.add(
        "runtime",
        sys.version_info >= (3, 10),
        "python {0}.{1}.{2}".format(*sys.version_info[:3]),
        "需要 Python 3.10 或更高版本",
    )

    portable = (base_dir / "python.exe").is_file()
    report.add(
        "package_layout",
        True,
        "portable bundle" if portable else "source tree",
        severity=WARN,
    )

    env_path = base_dir / ".env"
    values = read_env_file(env_path)
    if not env_path.is_file():
        report.add(
            "env_file",
            False,
            ".env not found",
            "先启动一次 start_control_panel.bat 自动生成 .env，或由 .env.example 复制后手工填写",
        )
    else:
        report.add("env_file", True, f".env found ({len(values)} keys)")

    config: Config | None = None
    try:
        config = Config.from_mapping(values, base_dir)
        report.add("env_required", True, "WSHOTO_CALLBACK_URL / MEIQIA_WEBHOOK_SECRET 已配置")
    except ConfigError as exc:
        report.add(
            "env_required",
            False,
            str(exc),
            "在控制台「连接配置」里补齐微盛 Webhook 地址和美洽密钥后点『保存配置』",
        )

    if config is None:
        return report

    secret = values.get("MEIQIA_WEBHOOK_SECRET", "")
    report.add(
        "secret_present",
        bool(secret) and not config.allow_unsigned_webhooks,
        "签名校验已启用" if secret else "未设置密钥",
        "正式环境必须填写美洽 Webhook 密钥，并关闭「允许无签名请求」",
    )
    if config.allow_unsigned_webhooks:
        report.add(
            "allow_unsigned",
            False,
            "ALLOW_UNSIGNED_WEBHOOKS=true",
            "正式环境必须改为 false，否则任何知道地址的人都能伪造线索",
            severity=WARN,
        )

    report.add(
        "host_binding",
        config.host in {"127.0.0.1", "0.0.0.0"},
        f"HOST={config.host}",
        "HOST 只能是 127.0.0.1 或 0.0.0.0",
    )
    if config.host == "0.0.0.0":
        report.add(
            "host_exposure",
            False,
            "监听全部网卡（HOST=0.0.0.0）",
            "仅在使用路由器端口映射时才需要 0.0.0.0；同机隧道请改回 127.0.0.1",
            severity=WARN,
        )

    data_dir = base_dir / "data"
    try:
        data_dir.mkdir(parents=True, exist_ok=True)
        probe = data_dir / ".preflight-write-test"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
        report.add("data_writable", True, str(data_dir))
    except OSError as exc:
        report.add(
            "data_writable",
            False,
            f"{type(exc).__name__}: {exc}",
            "把程序放到有写权限的目录（不要放在 C:\\Program Files 或只读盘）",
        )

    local_base = f"http://127.0.0.1:{config.port}"
    health, error = http_get_json(local_base + config.health_path, timeout)
    if health is None:
        report.add(
            "local_health",
            False,
            f"{local_base}{config.health_path} -> {error}",
            "服务没在运行：控制台点『启用服务』；若点了仍失败，看 data/control-panel.log",
        )
    else:
        report.add(
            "local_health",
            health.get("status") == "ok",
            f"status={health.get('status')} version={health.get('version')}",
            "本机健康检查返回 degraded，检查 data 目录和 SQLite 文件权限",
        )
        report.add(
            "local_version",
            str(health.get("version")) == __version__,
            f"running={health.get('version')} expected={__version__}",
            "运行中的服务版本与脚本不一致：停止服务后重新启动",
        )
        report.add(
            "local_webhook_path",
            health.get("webhook_path") == config.webhook_path,
            f"webhook_path={health.get('webhook_path')}",
            "运行的路径与 .env 不一致：重启服务",
        )

    public_url = base_url_override.strip() or values.get("PUBLIC_BASE_URL", "").strip()
    public_url = public_url.rstrip("/")
    if not public_url:
        report.add(
            "public_base",
            False,
            "PUBLIC_BASE_URL 未配置",
            "公网入口是前置条件：先装 Cloudflare Tunnel 拿到固定域名（见 DEPLOYMENT.md 第 3.5 节），"
            "再把该地址填到控制台「公网 URL」。这个输入框本身不创建隧道",
        )
        return report

    if not public_url.startswith("https://"):
        report.add(
            "public_scheme",
            False,
            f"PUBLIC_BASE_URL={public_url}",
            "美洽要求回调地址使用 HTTPS，请改成 https:// 开头",
        )
    else:
        report.add("public_scheme", True, "HTTPS")

    public_health, error = http_get_json(public_url + config.health_path, timeout)
    if public_health is None:
        report.add(
            "public_health",
            False,
            f"{public_url}{config.health_path} -> {error}",
            "公网打不到本机服务。依次检查：隧道进程是否在跑、控制台是否已启用服务、"
            "监听地址是否为 127.0.0.1、Cloudflare 是否把路径加了登录保护",
        )
    else:
        report.add(
            "public_health",
            public_health.get("status") == "ok",
            f"status={public_health.get('status')}",
            "公网可达但服务降级，检查本机 SQLite",
        )
        report.add(
            "public_identity",
            str(public_health.get("version")) == __version__
            and public_health.get("webhook_path") == config.webhook_path,
            "public version={0} path={1}".format(
                public_health.get("version"), public_health.get("webhook_path")
            ),
            "公网地址指向的不是这一份服务（版本或路径不一致），检查隧道/反代配置",
        )

    if probe_webhook and secret:
        signed = hashlib.sha1(PROBE_BODY + secret.encode("utf-8")).hexdigest()
        request = urllib.request.Request(
            public_url + config.webhook_path,
            data=PROBE_BODY,
            method="POST",
            headers={
                "Content-Type": "application/json; charset=utf-8",
                "X-MeiqiaAI-Signature": signed,
                "User-Agent": f"bridge-preflight/{__version__}",
            },
        )
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                code = int(response.status)
                payload = json.loads(response.read(4096) or b"{}")
            reason = payload.get("reason") or payload.get("message") or ""
            report.add(
                "webhook_roundtrip",
                code == 200 and reason in {"non_lead_event", "ignored"},
                f"HTTP {code} reason={reason}",
                "公网可访问但签名/业务层没通过：确认美洽密钥与控制台完全一致（注意首尾空格）",
            )
            report.add(
                "webhook_no_side_effect",
                reason == "non_lead_event",
                "探针事件被正确识别为非线索，未推送微盛",
                "探针事件被当成线索转发了：请核对服务版本，必要时到微盛删除该测试线索",
                severity=WARN,
            )
        except urllib.error.HTTPError as exc:
            report.add(
                "webhook_roundtrip",
                False,
                f"HTTP {exc.code}",
                "401 表示签名不一致；404 表示公网路径与 WEBHOOK_PATH 不一致",
            )
        except Exception as exc:  # noqa: BLE001
            report.add(
                "webhook_roundtrip",
                False,
                f"{type(exc).__name__}: {exc}",
                "公网 webhook 请求失败，先解决 public_health 那一项",
            )

    tls_ok, tls_detail = tcp_tls_probe(config.wshoto_callback_url, timeout)
    report.add(
        "wshoto_reachable",
        tls_ok,
        tls_detail,
        "客户电脑无法访问微盛：检查出网策略、代理、DNS 或地址是否填写正确",
    )

    return report


def print_human(report: Report) -> None:
    payload = report.as_dict()
    for check in payload["checks"]:
        if check["ok"]:
            mark = "PASS"
        elif check["severity"] == WARN:
            mark = "WARN"
        else:
            mark = "FAIL"
        print(f"[{mark}] {check['id']}: {check['detail']}")
        if check["hint"] and not check["ok"]:
            print(f"       -> {check['hint']}")
    summary = payload["summary"]
    print()
    print(
        "{passed}/{total} 项通过，{failed} 项失败，{warnings} 项提醒".format(**summary)
    )
    if payload["ok"]:
        print("预检通过：公网入口、验签链路和微盛可达性均正常。")
    else:
        print(f"预检未通过：{payload['next_action']}")


def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass

    parser = argparse.ArgumentParser(
        description="美洽 → 微盛线索转接：安装预检（输出 JSON）"
    )
    parser.add_argument("--human", action="store_true", help="输出人类可读文本而非 JSON")
    parser.add_argument("--timeout", type=float, default=6.0, help="单次网络超时秒数")
    parser.add_argument(
        "--base-url",
        default="",
        help="临时覆盖 PUBLIC_BASE_URL，用于在写入 .env 前先验证隧道",
    )
    parser.add_argument(
        "--no-probe-webhook",
        action="store_true",
        help="跳过公网 webhook 探针（不发送任何请求）",
    )
    args = parser.parse_args()

    report = run_checks(
        base_dir=ROOT,
        timeout=args.timeout,
        probe_webhook=not args.no_probe_webhook,
        base_url_override=args.base_url,
    )
    if args.human:
        print_human(report)
    else:
        print(json.dumps(report.as_dict(), ensure_ascii=False, indent=2))
    return 0 if report.as_dict()["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
