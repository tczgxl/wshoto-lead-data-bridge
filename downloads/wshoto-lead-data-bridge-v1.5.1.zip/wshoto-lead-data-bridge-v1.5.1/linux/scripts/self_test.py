#!/usr/bin/env python3
"""本地端到端自检：不访问真实微盛，不产生真实线索。"""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import secrets
import sys
import tempfile
import threading
import traceback
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from meiqia_bridge.config import Config
from meiqia_bridge.server import create_server

SECRET = secrets.token_urlsafe(32)


class MockWshotoHandler(BaseHTTPRequestHandler):
    received: list[dict[str, Any]] = []

    def do_POST(self) -> None:
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length)
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            payload = {"_raw": raw.decode("utf-8", errors="replace")}
        type(self).received.append(payload)

        body = json.dumps(
            {"code": "00000", "msg": "OK"},
            ensure_ascii=False,
        ).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt: str, *args: Any) -> None:
        return


def make_config(base_dir: Path, callback_url: str) -> Config:
    return Config(
        host="127.0.0.1",
        port=0,
        webhook_path="/webhook/meiqia",
        health_path="/healthz",
        wshoto_callback_url=callback_url,
        meiqia_webhook_secret=SECRET,
        allow_unsigned_webhooks=False,
        capture_raw_payloads=False,
        sqlite_path=base_dir / "bridge.sqlite3",
        raw_capture_dir=base_dir / "captured",
        wshoto_timeout_seconds=2.0,
        wshoto_max_attempts=2,
        max_body_bytes=1024 * 1024,
        log_level="INFO",
    )


def http_request(
    url: str,
    raw: bytes | None = None,
    signature: str | None = None,
) -> tuple[int, dict[str, Any]]:
    headers = {"Accept": "application/json"}
    if raw is not None:
        headers["Content-Type"] = "application/json; charset=utf-8"
    if signature:
        headers["X-MeiqiaAI-Signature"] = signature

    request = urllib.request.Request(
        url,
        data=raw,
        method="POST" if raw is not None else "GET",
        headers=headers,
    )
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            body = response.read()
            return response.status, json.loads(body or b"{}")
    except urllib.error.HTTPError as exc:
        body = exc.read()
        try:
            parsed = json.loads(body or b"{}")
        except json.JSONDecodeError:
            parsed = {"body": body.decode("utf-8", errors="replace")}
        return exc.code, parsed


def sign(raw: bytes) -> str:
    return hashlib.sha1(raw + SECRET.encode("utf-8")).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(
        description="启动本地 mock 微盛和转接服务，验证美洽样例的完整处理流程"
    )
    parser.add_argument(
        "--sample",
        default=str(ROOT / "examples" / "meiqia_doc_sample.json"),
        help="美洽样例 JSON 路径",
    )
    args = parser.parse_args()

    sample_raw = Path(args.sample).read_bytes()
    sample = json.loads(sample_raw)
    if not isinstance(sample, dict):
        print("样例必须是 JSON 对象", file=sys.stderr)
        return 2

    logging.getLogger("meiqia_bridge").setLevel(logging.CRITICAL)
    MockWshotoHandler.received = []
    checks: list[tuple[str, bool, str]] = []

    mock_server = ThreadingHTTPServer(("127.0.0.1", 0), MockWshotoHandler)
    mock_thread = threading.Thread(
        target=mock_server.serve_forever,
        name="mock-wshoto",
        daemon=True,
    )
    mock_thread.start()

    temp_dir = tempfile.TemporaryDirectory(prefix="meiqia-bridge-self-test-")
    bridge_server = None
    bridge_thread = None
    try:
        config = make_config(
            Path(temp_dir.name),
            f"http://127.0.0.1:{mock_server.server_port}/callback",
        )
        bridge_server = create_server(config)
        bridge_thread = threading.Thread(
            target=bridge_server.serve_forever,
            name="bridge",
            daemon=True,
        )
        bridge_thread.start()
        base_url = f"http://127.0.0.1:{bridge_server.server_port}"

        status, body = http_request(base_url + "/healthz")
        checks.append(
            (
                "健康检查",
                status == 200 and body.get("status") == "ok",
                f"HTTP {status} {body}",
            )
        )

        status, body = http_request(
            base_url + "/webhook/meiqia",
            sample_raw,
            sign(sample_raw),
        )
        checks.append(
            (
                "签名校验与转发",
                status == 200 and body.get("message") == "accepted",
                f"HTTP {status} {body}",
            )
        )
        forwarded = (
            MockWshotoHandler.received[0]
            if len(MockWshotoHandler.received) == 1
            else {}
        )
        checks.append(
            (
                "微盛入参已扁平化",
                forwarded.get("client_name") == "示例线索"
                and forwarded.get("tel") == "PHONE_PLACEHOLDER"
                and forwarded.get("customer_attrs.tel") == "PHONE_PLACEHOLDER"
                and "123" not in forwarded
                and "234" not in forwarded
                and "customer_attrs" not in forwarded,
                f"实际收到 {MockWshotoHandler.received}",
            )
        )

        status, body = http_request(
            base_url + "/webhook/meiqia",
            sample_raw,
            sign(sample_raw),
        )
        checks.append(
            (
                "重复请求去重",
                status == 200
                and body.get("duplicate") is True
                and len(MockWshotoHandler.received) == 1,
                f"HTTP {status} {body}",
            )
        )

        status, body = http_request(
            base_url + "/webhook/meiqia",
            sample_raw,
            "0" * 40,
        )
        checks.append(
            (
                "错误签名拒绝",
                status == 401 and len(MockWshotoHandler.received) == 1,
                f"HTTP {status} {body}",
            )
        )

        missing_mobile = json.loads(json.dumps(sample))
        missing_mobile["client_id"] = "self-test-missing-mobile"
        missing_mobile.pop("virtual_phone", None)
        attrs = missing_mobile.get("customer_attrs")
        if isinstance(attrs, dict):
            attrs.pop("tel", None)
        missing_raw = json.dumps(
            missing_mobile,
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8")
        status, body = http_request(
            base_url + "/webhook/meiqia",
            missing_raw,
            sign(missing_raw),
        )
        checks.append(
            (
                "缺手机号仍转发原始数据",
                status == 200
                and body.get("message") == "accepted"
                and len(MockWshotoHandler.received) == 2
                and MockWshotoHandler.received[1].get("tel") is None
                and MockWshotoHandler.received[1].get("client_name") == "示例线索",
                f"HTTP {status} {body}",
            )
        )
    except Exception:
        traceback.print_exc()
        checks.append(("自检执行", False, "发生未预期异常"))
    finally:
        if bridge_server is not None:
            bridge_server.shutdown()
            bridge_server.server_close()
            bridge_server.app.store.close()
        if bridge_thread is not None:
            bridge_thread.join(timeout=2)
        mock_server.shutdown()
        mock_server.server_close()
        mock_thread.join(timeout=2)
        temp_dir.cleanup()

    print()
    for name, passed, detail in checks:
        prefix = "[PASS]" if passed else "[FAIL]"
        print(f"{prefix} {name}" + (f" - {detail}" if not passed else ""))

    failed = sum(1 for _, passed, _ in checks if not passed)
    print(f"\n{len(checks) - failed}/{len(checks)} 项通过")
    if failed:
        print("自检失败：请把上面的输出发给技术支持。", file=sys.stderr)
        return 1
    print("自检通过：原始字段扁平化、微盛入参、验签和去重均正常。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
