#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

if [ ! -f .env ]; then
    cp .env.example .env
    chmod 600 .env 2>/dev/null || true
    echo "首次运行：已生成 .env"
    echo "请先填写 WSHOTO_CALLBACK_URL 和 MEIQIA_WEBHOOK_SECRET，然后重新执行 ./start.sh"
    exit 1
fi

if ! command -v python3 >/dev/null 2>&1; then
    echo "未找到 python3，请先安装 Python 3.10 或更高版本。"
    exit 1
fi

if ! python3 -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)'; then
    echo "Python 版本过低，需要 3.10 或更高版本。"
    python3 --version
    exit 1
fi

exec python3 app.py
