from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping


class ConfigError(ValueError):
    pass


def load_dotenv(path: Path) -> None:
    if not path.is_file():
        return

    for raw_line in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].lstrip()
        if "=" not in line:
            continue

        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not key:
            continue
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        os.environ.setdefault(key, value)


def _env_bool(
    values: Mapping[str, str],
    name: str,
    default: bool,
) -> bool:
    value = values.get(name)
    if value is None:
        return default
    normalized = value.strip().lower()
    if normalized in {"1", "true", "yes", "y", "on"}:
        return True
    if normalized in {"0", "false", "no", "n", "off"}:
        return False
    raise ConfigError(f"{name} 必须是 true/false")


def _env_int(
    values: Mapping[str, str],
    name: str,
    default: int,
    minimum: int,
    maximum: int,
) -> int:
    raw = values.get(name, str(default))
    try:
        value = int(raw)
    except ValueError as exc:
        raise ConfigError(f"{name} 必须是整数") from exc
    if not minimum <= value <= maximum:
        raise ConfigError(f"{name} 必须在 {minimum} 到 {maximum} 之间")
    return value


def _env_float(
    values: Mapping[str, str],
    name: str,
    default: float,
    minimum: float,
    maximum: float,
) -> float:
    raw = values.get(name, str(default))
    try:
        value = float(raw)
    except ValueError as exc:
        raise ConfigError(f"{name} 必须是数字") from exc
    if not minimum <= value <= maximum:
        raise ConfigError(f"{name} 必须在 {minimum} 到 {maximum} 之间")
    return value


def _normalize_path(value: str) -> str:
    path = value.strip()
    if not path.startswith("/"):
        path = "/" + path
    return path.rstrip("/") or "/"


@dataclass(frozen=True)
class Config:
    host: str
    port: int
    webhook_path: str
    health_path: str
    wshoto_callback_url: str
    meiqia_webhook_secret: str
    allow_unsigned_webhooks: bool
    capture_raw_payloads: bool
    sqlite_path: Path
    raw_capture_dir: Path
    wshoto_timeout_seconds: float
    wshoto_max_attempts: int
    max_body_bytes: int
    log_level: str

    @classmethod
    def from_env(cls, base_dir: Path | None = None) -> "Config":
        return cls.from_mapping(os.environ, base_dir)

    @classmethod
    def from_mapping(
        cls,
        values: Mapping[str, str],
        base_dir: Path | None = None,
    ) -> "Config":
        base_dir = base_dir or Path.cwd()
        callback_url = (values.get("WSHOTO_CALLBACK_URL") or "").strip()
        if not callback_url:
            raise ConfigError("WSHOTO_CALLBACK_URL 未设置")
        if not callback_url.startswith(("https://", "http://")):
            raise ConfigError("WSHOTO_CALLBACK_URL 必须是完整 URL")
        if "REPLACE_WITH_YOUR_TOKEN" in callback_url:
            raise ConfigError(
                "WSHOTO_CALLBACK_URL 仍是示例占位符，请填写微盛页面上的真实接收地址"
            )

        secret = (values.get("MEIQIA_WEBHOOK_SECRET") or "").strip()
        allow_unsigned = _env_bool(values, "ALLOW_UNSIGNED_WEBHOOKS", False)
        if not secret and not allow_unsigned:
            raise ConfigError(
                "MEIQIA_WEBHOOK_SECRET 未设置；本地临时联调可显式设置 "
                "ALLOW_UNSIGNED_WEBHOOKS=true"
            )

        sqlite_value = (
            values.get("SQLITE_PATH") or str(base_dir / "data" / "bridge.sqlite3")
        ).strip()
        sqlite_path = Path(sqlite_value).expanduser()
        if not sqlite_path.is_absolute():
            sqlite_path = (base_dir / sqlite_path).resolve()

        raw_capture_value = (
            values.get("RAW_CAPTURE_DIR") or str(base_dir / "data" / "captured")
        ).strip()
        raw_capture_dir = Path(raw_capture_value).expanduser()
        if not raw_capture_dir.is_absolute():
            raw_capture_dir = (base_dir / raw_capture_dir).resolve()

        return cls(
            host=(values.get("HOST") or "0.0.0.0").strip(),
            port=_env_int(values, "PORT", 8080, 1, 65535),
            webhook_path=_normalize_path(
                values.get("WEBHOOK_PATH") or "/webhook/meiqia"
            ),
            health_path=_normalize_path(
                values.get("HEALTH_PATH") or "/healthz"
            ),
            wshoto_callback_url=callback_url,
            meiqia_webhook_secret=secret,
            allow_unsigned_webhooks=allow_unsigned,
            capture_raw_payloads=_env_bool(values, "CAPTURE_RAW_PAYLOADS", False),
            sqlite_path=sqlite_path,
            raw_capture_dir=raw_capture_dir,
            wshoto_timeout_seconds=_env_float(
                values,
                "WSHOTO_TIMEOUT_SECONDS",
                8.0,
                1.0,
                60.0,
            ),
            wshoto_max_attempts=_env_int(values, "WSHOTO_MAX_ATTEMPTS", 3, 1, 6),
            max_body_bytes=_env_int(
                values,
                "MAX_BODY_BYTES",
                1_048_576,
                1024,
                10_485_760,
            ),
            log_level=(values.get("LOG_LEVEL") or "INFO").strip().upper() or "INFO",
        )
