from __future__ import annotations

import os
import sqlite3
import threading
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path


@dataclass(frozen=True)
class BeginResult:
    should_forward: bool
    duplicate: bool
    in_progress: bool


class EventStore:
    def __init__(self, path: Path, processing_timeout_seconds: int = 300) -> None:
        self.path = path
        self.processing_timeout = timedelta(seconds=processing_timeout_seconds)
        self._lock = threading.Lock()
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(path.parent, 0o700)
        except OSError:
            pass
        self._connection = sqlite3.connect(
            str(path),
            check_same_thread=False,
            isolation_level=None,
        )
        try:
            os.chmod(path, 0o600)
            os.chmod(str(path) + "-wal", 0o600)
            os.chmod(str(path) + "-shm", 0o600)
        except OSError:
            pass
        self._connection.execute("PRAGMA journal_mode=WAL")
        self._connection.execute("PRAGMA synchronous=FULL")
        self._connection.execute("PRAGMA busy_timeout=5000")
        self._connection.execute(
            """
            CREATE TABLE IF NOT EXISTS events (
                event_key TEXT PRIMARY KEY,
                client_id TEXT NOT NULL,
                status TEXT NOT NULL,
                attempts INTEGER NOT NULL DEFAULT 0,
                last_http_status INTEGER,
                last_error TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
            """
        )

    def close(self) -> None:
        with self._lock:
            self._connection.close()

    def ping(self) -> bool:
        with self._lock:
            row = self._connection.execute("SELECT 1").fetchone()
        return bool(row and row[0] == 1)

    def begin(self, event_key: str, client_id: str) -> BeginResult:
        now = _utc_now()
        with self._lock:
            self._connection.execute("BEGIN IMMEDIATE")
            try:
                row = self._connection.execute(
                    """
                    SELECT status, updated_at
                    FROM events
                    WHERE event_key = ?
                    """,
                    (event_key,),
                ).fetchone()
                if row:
                    status, updated_at = row
                    if status in {"sent", "ignored"}:
                        self._connection.execute("COMMIT")
                        return BeginResult(False, True, False)
                    if status == "processing" and not _is_stale(
                        updated_at, self.processing_timeout
                    ):
                        self._connection.execute("COMMIT")
                        return BeginResult(False, False, True)
                    self._connection.execute(
                        """
                        UPDATE events
                        SET status = 'processing',
                            attempts = attempts + 1,
                            updated_at = ?
                        WHERE event_key = ?
                        """,
                        (now, event_key),
                    )
                else:
                    self._connection.execute(
                        """
                        INSERT INTO events (
                            event_key, client_id, status, attempts, created_at, updated_at
                        ) VALUES (?, ?, 'processing', 1, ?, ?)
                        """,
                        (event_key, client_id, now, now),
                    )
                self._connection.execute("COMMIT")
                return BeginResult(True, False, False)
            except Exception:
                self._connection.execute("ROLLBACK")
                raise

    def mark_sent(self, event_key: str, http_status: int | None = None) -> None:
        self._finish(event_key, "sent", http_status=http_status, error=None)

    def mark_ignored(self, event_key: str, reason: str) -> None:
        self._finish(event_key, "ignored", http_status=None, error=reason)

    def mark_failed(
        self,
        event_key: str,
        error: str,
        http_status: int | None = None,
    ) -> None:
        self._finish(event_key, "failed", http_status=http_status, error=error)

    def _finish(
        self,
        event_key: str,
        status: str,
        http_status: int | None,
        error: str | None,
    ) -> None:
        with self._lock:
            self._connection.execute(
                """
                UPDATE events
                SET status = ?,
                    last_http_status = ?,
                    last_error = ?,
                    updated_at = ?
                WHERE event_key = ? AND status = 'processing'
                """,
                (
                    status,
                    http_status,
                    (error or "")[:500] or None,
                    _utc_now(),
                    event_key,
                ),
            )


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _is_stale(timestamp: str, timeout: timedelta) -> bool:
    try:
        parsed = datetime.fromisoformat(timestamp)
    except (TypeError, ValueError):
        return True
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return datetime.now(timezone.utc) - parsed > timeout
