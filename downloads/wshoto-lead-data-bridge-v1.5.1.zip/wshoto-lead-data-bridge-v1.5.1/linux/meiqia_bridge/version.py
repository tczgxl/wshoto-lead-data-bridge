"""Single source of truth for the bridge version."""

__version__ = "1.5.1"
