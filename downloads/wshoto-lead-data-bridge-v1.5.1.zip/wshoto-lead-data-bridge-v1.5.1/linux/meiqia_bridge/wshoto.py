from __future__ import annotations

import json
import socket
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any

from .version import __version__


@dataclass(frozen=True)
class WshotoResult:
    ok: bool
    status: int | None
    body: str
    error: str
    attempts: int


class WshotoClient:
    def __init__(
        self,
        callback_url: str,
        timeout_seconds: float = 8.0,
        max_attempts: int = 3,
    ) -> None:
        self.callback_url = callback_url
        self.timeout_seconds = timeout_seconds
        self.max_attempts = max_attempts

    def send(self, payload: dict[str, Any]) -> WshotoResult:
        body = json.dumps(
            payload,
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8")
        last_status: int | None = None
        last_body = ""
        last_error = ""
        attempts_made = 0

        for attempt in range(1, self.max_attempts + 1):
            attempts_made = attempt
            request = urllib.request.Request(
                self.callback_url,
                data=body,
                method="POST",
                headers={
                    "Content-Type": "application/json; charset=utf-8",
                    "Accept": "application/json",
                    "User-Agent": f"Meiqia-Wshoto-Lead-Bridge/{__version__}",
                },
            )
            try:
                with urllib.request.urlopen(
                    request,
                    timeout=self.timeout_seconds,
                ) as response:
                    response_body = _read_response_body(response)
                    status = int(response.status)
                    if 200 <= status < 300:
                        business_error = _detect_business_error(response_body)
                        if not business_error:
                            return WshotoResult(
                                True,
                                status,
                                response_body,
                                "",
                                attempt,
                            )
                        last_status = status
                        last_body = response_body
                        last_error = business_error
                        break
                    last_status = status
                    last_body = response_body
                    last_error = f"HTTP {status}"
                    if not _retryable_status(status) or attempt == self.max_attempts:
                        break
            except urllib.error.HTTPError as exc:
                last_status = int(exc.code)
                try:
                    last_body = _read_error_body(exc)
                    last_error = f"HTTP {exc.code}"
                    should_retry = (
                        _retryable_status(exc.code)
                        and attempt != self.max_attempts
                    )
                finally:
                    exc.close()
                if not should_retry:
                    break
            except (urllib.error.URLError, socket.timeout, TimeoutError) as exc:
                last_error = f"{type(exc).__name__}: {exc}"
                if attempt == self.max_attempts:
                    break
            except Exception as exc:
                last_error = f"{type(exc).__name__}: {exc}"
                if attempt == self.max_attempts:
                    break

            time.sleep(_backoff_seconds(attempt))

        return WshotoResult(
            ok=False,
            status=last_status,
            body=last_body,
            error=last_error or "forward_failed",
            attempts=attempts_made,
        )


def _retryable_status(status: int) -> bool:
    return status in {408, 425, 429} or 500 <= status <= 599


def _backoff_seconds(attempt: int) -> float:
    return min(0.3 * (2 ** (attempt - 1)), 2.0)


def _read_response_body(response: Any) -> str:
    try:
        raw = response.read(4096)
    except Exception:
        return ""
    return _decode_body(raw)


def _read_error_body(error: urllib.error.HTTPError) -> str:
    try:
        return _decode_body(error.read(4096))
    except Exception:
        return ""


def _decode_body(raw: bytes) -> str:
    return raw.decode("utf-8", errors="replace").strip()


def _detect_business_error(body: str) -> str:
    if not body:
        return ""
    try:
        parsed = json.loads(body)
    except json.JSONDecodeError:
        return ""
    if not isinstance(parsed, dict):
        return ""

    success = parsed.get("success")
    if isinstance(success, bool) and not success:
        return "business error: success=false"

    for key in ("errcode", "code", "statusCode"):
        if key not in parsed:
            continue
        code = parsed[key]
        if _is_success_code(code):
            return ""
        message = parsed.get("errmsg") or parsed.get("msg") or parsed.get("message")
        suffix = f": {message}" if message else ""
        return f"business error: {key}={code}{suffix}"
    return ""


def _is_success_code(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, int):
        return value in {0, 200, 20000}
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"200", "20000", "ok", "success"}:
            return True
        return bool(normalized) and normalized.isdigit() and set(normalized) == {"0"}
    return False
