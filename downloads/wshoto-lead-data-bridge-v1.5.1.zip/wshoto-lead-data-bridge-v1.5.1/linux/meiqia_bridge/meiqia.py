from __future__ import annotations

import hashlib
import hmac
import json
import re
from typing import Any, Mapping


class MeiqiaPayloadError(ValueError):
    def __init__(self, message: str, code: str) -> None:
        super().__init__(message)
        self.code = code


def verify_signature(raw_body: bytes, secret: str, received_signature: str | None) -> bool:
    if not secret or not received_signature:
        return False
    expected = hashlib.sha1(raw_body + secret.encode("utf-8")).hexdigest()
    return hmac.compare_digest(expected, received_signature.strip().lower())


def canonical_json(payload: Mapping[str, Any]) -> str:
    return json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def flatten_payload(payload: Any) -> dict[str, Any]:
    """Flatten Meiqia JSON into one level while preserving every leaf value."""
    if not isinstance(payload, dict):
        raise MeiqiaPayloadError("请求体必须是 JSON 对象", "invalid_payload")

    root = _unwrap_payload(payload)
    flattened: dict[str, Any] = {}

    def walk(value: Any, path: str) -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                child_path = f"{path}.{key}" if path else str(key)
                walk(child, child_path)
            return
        if isinstance(value, (list, tuple)):
            if not value:
                return
            if all(_is_flat_scalar(item) for item in value):
                values = [
                    text
                    for item in value
                    if (text := _flat_scalar_text(item))
                ]
                if values:
                    flattened[path] = (
                        values[0] if len(values) == 1 else ", ".join(values)
                    )
                return
            for index, child in enumerate(value):
                walk(child, f"{path}[{index}]")
            return
        text = _flat_scalar_text(value)
        if text:
            flattened[path] = text

    for key, value in root.items():
        walk(value, str(key))

    aliases: dict[str, list[Any]] = {}
    for path, value in flattened.items():
        leaf = _leaf_key(path)
        if leaf:
            aliases.setdefault(leaf, []).append(value)
    for leaf, values in aliases.items():
        if leaf in flattened:
            continue
        unique_values = {_alias_value(value) for value in values}
        if len(unique_values) == 1:
            flattened[leaf] = values[0]
    return flattened


def build_event_key(payload: Mapping[str, Any], source_event_id: str | None = None) -> str:
    if source_event_id:
        basis = "event-id:" + source_event_id.strip()
    else:
        basis = "payload:" + canonical_json(payload)
    return hashlib.sha256(basis.encode("utf-8")).hexdigest()


def extract_client_id(payload: Any) -> str:
    if not isinstance(payload, dict):
        return ""
    return _as_text(_unwrap_payload(payload).get("client_id"))


def is_channel_auth_event(payload: Any) -> bool:
    if not isinstance(payload, dict):
        return False
    root = _unwrap_payload(payload)
    return (
        "client_id" not in root
        and "customer_attrs" not in root
        and "event_type" in root
        and ("channel_name" in root or "channel_sub_source" in root)
    )


def _unwrap_payload(payload: dict[str, Any]) -> dict[str, Any]:
    if "client_id" in payload:
        return payload
    data = payload.get("data")
    if isinstance(data, dict) and ("client_id" in data or "customer_attrs" in data):
        return data
    return payload


def _as_text(value: Any) -> str:
    if value is None or isinstance(value, bool):
        return ""
    if isinstance(value, (str, int, float)):
        return str(value).strip()
    return ""


def _is_flat_scalar(value: Any) -> bool:
    return value is None or isinstance(value, (str, int, float, bool))


def _flat_scalar_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (str, int, float)):
        return str(value).strip()
    return ""


def _leaf_key(path: str) -> str:
    return re.sub(r"\[\d+\]$", "", path).rsplit(".", 1)[-1]


def _alias_value(value: Any) -> tuple[type[Any], str]:
    return (type(value), str(value))
