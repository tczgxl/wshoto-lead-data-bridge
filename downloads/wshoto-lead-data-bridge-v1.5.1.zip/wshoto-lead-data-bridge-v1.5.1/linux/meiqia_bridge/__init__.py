"""Meiqia customer Webhook to Wshoto custom advertisement bridge."""

from .config import Config
from .version import __version__
from .meiqia import (
    MeiqiaPayloadError,
    extract_client_id,
    flatten_payload,
    is_channel_auth_event,
    verify_signature,
)
from .server import BridgeHTTPServer, create_server
from .store import EventStore
from .wshoto import WshotoClient, WshotoResult

__all__ = [
    "BridgeHTTPServer",
    "Config",
    "EventStore",
    "MeiqiaPayloadError",
    "WshotoClient",
    "WshotoResult",
    "__version__",
    "create_server",
    "extract_client_id",
    "flatten_payload",
    "is_channel_auth_event",
    "verify_signature",
]
