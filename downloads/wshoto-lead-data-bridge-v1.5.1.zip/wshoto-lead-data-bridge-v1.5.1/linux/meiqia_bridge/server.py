from __future__ import annotations

import hashlib
import json
import logging
import os
from datetime import datetime
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib.parse import urlsplit

from .config import Config
from .meiqia import (
    build_event_key,
    extract_client_id,
    flatten_payload,
    is_channel_auth_event,
    verify_signature,
)
from .store import EventStore
from .version import __version__
from .wshoto import WshotoClient, WshotoResult

logger = logging.getLogger("meiqia_bridge")


class BridgeApplication:
    def __init__(
        self,
        config: Config,
        store: EventStore,
        wshoto_client: WshotoClient,
    ) -> None:
        self.config = config
        self.store = store
        self.wshoto_client = wshoto_client

    def process(
        self,
        raw_body: bytes,
        signature: str | None,
        source_event_id: str | None,
    ) -> tuple[int, dict[str, Any]]:
        if self.config.meiqia_webhook_secret:
            if not verify_signature(
                raw_body,
                self.config.meiqia_webhook_secret,
                signature,
            ):
                logger.warning("rejected invalid Meiqia signature")
                return HTTPStatus.UNAUTHORIZED, {
                    "code": HTTPStatus.UNAUTHORIZED,
                    "message": "invalid signature",
                }
        elif not self.config.allow_unsigned_webhooks:
            return HTTPStatus.UNAUTHORIZED, {
                "code": HTTPStatus.UNAUTHORIZED,
                "message": "signature is not configured",
            }
        else:
            logger.warning("processing unsigned webhook; debug mode only")

        if self.config.capture_raw_payloads:
            self._capture_raw_payload(raw_body)

        try:
            payload = json.loads(raw_body)
        except (UnicodeDecodeError, json.JSONDecodeError):
            return HTTPStatus.BAD_REQUEST, {
                "code": HTTPStatus.BAD_REQUEST,
                "message": "invalid json",
            }

        if not isinstance(payload, dict):
            return HTTPStatus.BAD_REQUEST, {
                "code": HTTPStatus.BAD_REQUEST,
                "message": "json object required",
            }
        if is_channel_auth_event(payload):
            logger.info("ignored non-lead Meiqia event")
            return HTTPStatus.OK, {
                "code": 0,
                "message": "ignored",
                "reason": "non_lead_event",
            }

        event_key = build_event_key(payload, source_event_id)
        client_id = extract_client_id(payload) or f"anonymous-{event_key[:24]}"
        begin = self.store.begin(event_key, client_id)
        if begin.duplicate:
            logger.info("duplicate event client_id=%s", client_id)
            return HTTPStatus.OK, {
                "code": 0,
                "message": "duplicate",
                "duplicate": True,
            }
        if begin.in_progress:
            logger.info("event is already processing client_id=%s", client_id)
            return HTTPStatus.SERVICE_UNAVAILABLE, {
                "code": HTTPStatus.SERVICE_UNAVAILABLE,
                "message": "event is processing",
            }

        wshoto_payload = flatten_payload(payload)
        try:
            result = self.wshoto_client.send(wshoto_payload)
        except Exception as exc:
            result = WshotoResult(
                ok=False,
                status=None,
                body="",
                error=f"{type(exc).__name__}: {exc}",
                attempts=0,
            )

        if result.ok:
            self.store.mark_sent(event_key, result.status)
            logger.info(
                "forwarded client_id=%s keys=%s wshoto_status=%s",
                client_id,
                len(wshoto_payload),
                result.status,
            )
            return HTTPStatus.OK, {
                "code": 0,
                "message": "accepted",
                "duplicate": False,
            }

        error = _sanitize_error(result.error)
        self.store.mark_failed(event_key, error, result.status)
        logger.error(
            "forward failed client_id=%s status=%s attempts=%s error=%s",
            client_id,
            result.status,
            result.attempts,
            error,
        )
        return HTTPStatus.BAD_GATEWAY, {
            "code": HTTPStatus.BAD_GATEWAY,
            "message": "wshoto callback failed",
        }

    def _capture_raw_payload(self, raw_body: bytes) -> None:
        try:
            directory = self.config.raw_capture_dir
            directory.mkdir(parents=True, exist_ok=True)
            os.chmod(directory, 0o700)
            digest = hashlib.sha256(raw_body).hexdigest()[:12]
            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
            target = directory / f"{timestamp}-{digest}.json"
            temporary = target.with_suffix(".json.tmp")
            descriptor = os.open(
                temporary,
                os.O_WRONLY | os.O_CREAT | os.O_EXCL,
                0o600,
            )
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(raw_body)
            temporary.replace(target)
            os.chmod(target, 0o600)
            logger.info("captured raw test payload path=%s", target)
        except Exception:
            logger.exception("failed to capture raw test payload")


class BridgeRequestHandler(BaseHTTPRequestHandler):
    server_version = f"MeiqiaWshotoBridge/{__version__}"

    @property
    def app(self) -> BridgeApplication:
        return self.server.app  # type: ignore[attr-defined]

    def do_GET(self) -> None:
        path = urlsplit(self.path).path
        if path == self.app.config.health_path:
            healthy = self.app.store.ping()
            self._send_json(
                HTTPStatus.OK if healthy else HTTPStatus.SERVICE_UNAVAILABLE,
                {
                    "status": "ok" if healthy else "degraded",
                    "version": __version__,
                    "webhook_path": self.app.config.webhook_path,
                    "signature_enabled": bool(
                        self.app.config.meiqia_webhook_secret
                    ),
                },
            )
            return
        if path == "/":
            self._send_json(
                HTTPStatus.OK,
                {
                    "service": "meiqia-wshoto-lead-bridge",
                    "version": __version__,
                    "webhook_path": self.app.config.webhook_path,
                },
            )
            return
        self._send_json(
            HTTPStatus.NOT_FOUND,
            {"code": HTTPStatus.NOT_FOUND, "message": "not found"},
        )

    def do_POST(self) -> None:
        path = urlsplit(self.path).path
        if path != self.app.config.webhook_path:
            self._send_json(
                HTTPStatus.NOT_FOUND,
                {"code": HTTPStatus.NOT_FOUND, "message": "not found"},
            )
            return

        content_length_raw = self.headers.get("Content-Length", "")
        try:
            content_length = int(content_length_raw)
        except ValueError:
            self._send_json(
                HTTPStatus.LENGTH_REQUIRED,
                {"code": HTTPStatus.LENGTH_REQUIRED, "message": "content-length required"},
            )
            return
        if content_length <= 0:
            self._send_json(
                HTTPStatus.BAD_REQUEST,
                {"code": HTTPStatus.BAD_REQUEST, "message": "empty body"},
            )
            return
        if content_length > self.app.config.max_body_bytes:
            self._send_json(
                HTTPStatus.REQUEST_ENTITY_TOO_LARGE,
                {
                    "code": HTTPStatus.REQUEST_ENTITY_TOO_LARGE,
                    "message": "body too large",
                },
            )
            return

        raw_body = self.rfile.read(content_length)
        signature = self.headers.get("X-MeiqiaAI-Signature")
        source_event_id = (
            self.headers.get("Idempotency-Key")
            or self.headers.get("X-Event-Id")
            or self.headers.get("X-MeiqiaAI-Event-Id")
        )

        try:
            status, response = self.app.process(
                raw_body,
                signature,
                source_event_id,
            )
        except Exception:
            logger.exception("unhandled webhook error")
            status, response = HTTPStatus.INTERNAL_SERVER_ERROR, {
                "code": HTTPStatus.INTERNAL_SERVER_ERROR,
                "message": "internal server error",
            }
        self._send_json(status, response)

    def log_message(self, fmt: str, *args: Any) -> None:
        logger.info(
            "%s - %s",
            self.address_string(),
            fmt % args,
        )

    def _send_json(self, status: int, payload: dict[str, Any]) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(int(status))
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)


class BridgeHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(
        self,
        server_address: tuple[str, int],
        app: BridgeApplication,
    ) -> None:
        super().__init__(server_address, BridgeRequestHandler)
        self.app = app


def create_server(config: Config) -> BridgeHTTPServer:
    store = EventStore(config.sqlite_path)
    wshoto_client = WshotoClient(
        callback_url=config.wshoto_callback_url,
        timeout_seconds=config.wshoto_timeout_seconds,
        max_attempts=config.wshoto_max_attempts,
    )
    app = BridgeApplication(config, store, wshoto_client)
    try:
        return BridgeHTTPServer((config.host, config.port), app)
    except Exception:
        store.close()
        raise


def _sanitize_error(value: str) -> str:
    return " ".join(value.split())[:300]
